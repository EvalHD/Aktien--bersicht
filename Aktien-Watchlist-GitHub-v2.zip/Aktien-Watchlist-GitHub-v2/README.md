# Aktien-Watchlist (Android-App, wird von GitHub gebaut)

## Inhalt
- `aktien-app-source.zip` – der komplette App-Quellcode (Kotlin + Jetpack Compose)
- `.github/workflows/build-android.yml` – Anleitung für GitHub: ZIP entpacken, APK bauen, als Release bereitstellen

## Schritt für Schritt
1. Auf github.com ein neues **privates** Repository anlegen (z. B. `aktien-watchlist`).
2. Im Repository: **Add file → Create new file**. Als Dateinamen exakt `.github/workflows/build-android.yml` eintippen (die Schrägstriche erzeugen die Ordner). Den Inhalt der mitgelieferten Datei einfügen → **Commit changes**.
3. **Add file → Upload files** → `aktien-app-source.zip` hochladen (die ZIP NICHT entpacken) → **Commit changes**.
4. Reiter **Actions** öffnen. Der Lauf „Android APK bauen" startet automatisch (sonst: Workflow wählen → **Run workflow**). Der erste Lauf dauert ca. 5–10 Minuten.
5. Grüner Haken = fertig. Die APK liegt rechts im Repository unter **Releases → Build N → Aktien-Watchlist.apk** (alternativ im Lauf unter **Artifacts**).
6. APK aufs Android-Gerät laden und installieren (Android fragt einmal nach der Erlaubnis für „unbekannte Apps").

## Neue Version bauen
Verbesserte `aktien-app-source.zip` im Repository hochladen und denselben Dateinamen überschreiben – GitHub baut automatisch neu.

## Stand
Prototyp: Watchlist mit 54 Unternehmen, Hinzufügen/Entfernen, dauerhaftes Speichern, Widget liest dieselbe Liste.
Noch **keine echten Kursdaten** und keine Diagramme. Dafür braucht es einen Datenanbieter (Nutzungsbedingungen und Limits prüfen; kostenlose Kurse sind oft verzögert).
